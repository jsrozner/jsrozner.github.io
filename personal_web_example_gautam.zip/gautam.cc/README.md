<h1>gautam.cc</h1>
<hr />
My personal blog. If you have any questions, feel free to email <a href="mailto:gautam@mittal.net">me</a>.